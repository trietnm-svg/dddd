/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  AreaChart,
  Area,
} from 'recharts';
import { Sun, Zap, Info, Settings2, Activity, Download, Share2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

// Utility for tailwind classes
function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// --- Physics Constants & Utilities ---

const WAVELENGTHS = Array.from({ length: 81 }, (_, i) => 380 + i * 5); // 380nm to 780nm

// Gaussian function for spectrum modeling
const gaussian = (x: number, mu: number, sigma: number) => {
  return Math.exp(-Math.pow(x - mu, 2) / (2 * Math.pow(sigma, 2)));
};

// Simple XYZ to RGB conversion (refined for warmer white bias)
const spectrumToRGB = (spectrum: { x: number; y: number }[]) => {
  let r = 0, g = 0, b = 0;
  spectrum.forEach((p) => {
    const w = p.x;
    const v = p.y;
    // Spectral sensitivity curves (approximate)
    if (w >= 380 && w < 440) { r += v * 0.05; b += v * 0.6; }
    else if (w >= 440 && w < 490) { b += v * 0.8; g += v * 0.1; }
    else if (w >= 490 && w < 510) { g += v * 0.8; b += v * 0.4; }
    else if (w >= 510 && w < 580) { g += v; r += v * 0.6; }
    else if (w >= 580 && w < 645) { r += v; g += v * 0.4; }
    else if (w >= 645 && w <= 780) { r += v * 1.1; } // Boost red for warmth
  });

  const max = Math.max(r, g, b, 1);
  // Apply a slight warm tint by scaling B down slightly
  const finalR = Math.min(255, (r / max) * 255);
  const finalG = Math.min(255, (g / max) * 255 * 0.98);
  const finalB = Math.min(255, (b / max) * 255 * 0.85);
  
  return `rgb(${Math.round(finalR)}, ${Math.round(finalG)}, ${Math.round(finalB)})`;
};

// McCamy's formula for CCT approximation
const calculateCCT = (blueInt: number, yellowInt: number) => {
  const ratio = yellowInt / (blueInt + 0.001);
  if (ratio < 0.2) return 15000;
  if (ratio > 5) return 2000;
  const t = Math.min(1, ratio / 2.5);
  return Math.round(7000 - t * 4300);
};

// Simplified XY Coordinates for CIE 1931
const calculateXY = (blueInt: number, yellowInt: number) => {
  // Blue peak is roughly at (0.15, 0.05)
  // Yellow phosphor is roughly at (0.45, 0.50)
  const total = blueInt + yellowInt + 0.001;
  const x = (blueInt * 0.15 + yellowInt * 0.45) / total;
  const y = (blueInt * 0.05 + yellowInt * 0.50) / total;
  return { x, y };
};

// Simplified CRI approximation
const calculateCRI = (blueInt: number, yellowInt: number, redInt: number = 0) => {
  // Base CRI for Blue + Yellow is usually 70-82
  const ratio = yellowInt / (blueInt + 0.001);
  const balance = 1 - Math.abs(ratio - 1.2) / 2;
  let score = 72 + Math.max(0, balance * 12);
  
  // Red phosphor (Nitride/KSF) fills the deep red gap (R9)
  // This is the primary way to reach CRI > 90 in commercial LEDs
  if (redInt > 0) {
    // The boost is proportional to the red intensity
    const boost = redInt * 14; 
    score += boost;
  }
  
  return Math.min(98, Math.round(score));
};

export default function App() {
  const [blueIntensity, setBlueIntensity] = useState(0.4);
  const [yellowIntensity, setYellowIntensity] = useState(0.8);
  const [redIntensity, setRedIntensity] = useState(0.3);
  const [isRedEnabled, setIsRedEnabled] = useState(false);

  const spectrumData = useMemo(() => {
    return WAVELENGTHS.map((wl) => {
      const blue = blueIntensity * gaussian(wl, 450, 15);
      const yellow = yellowIntensity * gaussian(wl, 560, 50);
      const red = isRedEnabled ? redIntensity * gaussian(wl, 630, 20) : 0;
      return {
        wavelength: wl,
        intensity: blue + yellow + red,
        blue: blue,
        yellow: yellow,
        red: red,
      };
    });
  }, [blueIntensity, yellowIntensity, redIntensity, isRedEnabled]);

  const outputColor = useMemo(() => {
    const data = spectrumData.map(d => ({ x: d.wavelength, y: d.intensity }));
    return spectrumToRGB(data);
  }, [spectrumData]);

  const cct = useMemo(() => calculateCCT(blueIntensity, yellowIntensity + (isRedEnabled ? redIntensity * 0.6 : 0)), [blueIntensity, yellowIntensity, redIntensity, isRedEnabled]);
  const cri = useMemo(() => calculateCRI(blueIntensity, yellowIntensity, isRedEnabled ? redIntensity : 0), [blueIntensity, yellowIntensity, redIntensity, isRedEnabled]);
  const chromaticity = useMemo(() => {
    const total = blueIntensity + yellowIntensity + (isRedEnabled ? redIntensity : 0) + 0.001;
    const x = (blueIntensity * 0.15 + yellowIntensity * 0.45 + (isRedEnabled ? redIntensity * 0.65 : 0)) / total;
    const y = (blueIntensity * 0.05 + yellowIntensity * 0.50 + (isRedEnabled ? redIntensity * 0.30 : 0)) / total;
    return { x, y };
  }, [blueIntensity, yellowIntensity, redIntensity, isRedEnabled]);

  const handleExportHTML = () => {
    const reportDate = new Date().toLocaleString();
    const htmlContent = `
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mô phỏng LED Phosphor - ${reportDate}</title>
    <!-- Thư viện nền tảng -->
    <script src="https://cdn.jsdelivr.net/npm/react@18/umd/react.production.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/react-dom@18/umd/react-dom.production.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@babel/standalone/babel.min.js"></script>
    
    <!-- Thư viện bổ trợ -->
    <script src="https://cdn.jsdelivr.net/npm/framer-motion@10.16.4/dist/framer-motion.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/recharts@2.10.3/umd/Recharts.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/lucide@latest"></script>
    <script src="https://cdn.tailwindcss.com"></script>
    
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@400;700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; background-color: #f5f5f4; margin: 0; overflow-x: hidden; }
        .font-mono { font-family: 'JetBrains Mono', monospace; }
        input[type="range"] { accent-color: #2563eb; cursor: pointer; }
        #loading-screen {
            position: fixed; top: 0; left: 0; width: 100%; height: 100%;
            background: white; display: flex; flex-direction: column;
            align-items: center; justify-content: center; z-index: 9999;
            transition: opacity 0.5s ease;
        }
        .spinner {
            width: 40px; height: 40px; border: 4px solid #f3f3f3;
            border-top: 4px solid #2563eb; border-radius: 50%;
            animation: spin 1s linear infinite;
        }
        @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
    </style>
</head>
<body>
    <div id="loading-screen">
        <div class="spinner"></div>
        <p style="margin-top: 20px; color: #444; font-weight: 600;">Đang khởi tạo thí nghiệm...</p>
        <p style="margin-top: 10px; color: #888; font-size: 13px; max-width: 300px; text-align: center;">
            Lưu ý: Cần kết nối Internet trong lần đầu mở file để tải các thành phần cần thiết.
        </p>
    </div>

    <div id="root"></div>

    <script type="text/babel">
        const { useState, useMemo, useEffect } = React;
        
        // Phát hiện thư viện Motion linh hoạt
        const MotionLib = window.Motion || window.framerMotion;
        const motion = MotionLib ? MotionLib.motion : {
            div: (props) => <div {...props} />,
            rect: (props) => <rect {...props} />,
            circle: (props) => <circle {...props} />,
            g: (props) => <g {...props} />,
            path: (props) => <path {...props} />
        };
        const AnimatePresence = MotionLib ? MotionLib.AnimatePresence : ({children}) => children;
        
        // Phát hiện Recharts
        const RechartsLib = window.Recharts;
        const { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } = RechartsLib || {};
        
        const WAVELENGTHS = Array.from({ length: 81 }, (_, i) => 380 + i * 5);
        const gaussian = (x, mu, sigma) => Math.exp(-Math.pow(x - mu, 2) / (2 * Math.pow(sigma, 2)));

        const spectrumToRGB = (spectrum) => {
            if (!spectrum) return 'rgb(200, 200, 200)';
            let r = 0, g = 0, b = 0;
            spectrum.forEach((p) => {
                const w = p.x; const v = p.y;
                if (w >= 380 && w < 440) { r += v * 0.05; b += v * 0.6; }
                else if (w >= 440 && w < 490) { b += v * 0.8; g += v * 0.1; }
                else if (w >= 490 && w < 510) { g += v * 0.8; b += v * 0.4; }
                else if (w >= 510 && w < 580) { g += v; r += v * 0.6; }
                else if (w >= 580 && w < 645) { r += v; g += v * 0.4; }
                else if (w >= 645 && w <= 780) { r += v * 1.1; }
            });
            const max = Math.max(r, g, b, 1);
            return \`rgb(\${Math.round(Math.min(255, (r/max)*255))}, \${Math.round(Math.min(255, (g/max)*255*0.98))}, \${Math.round(Math.min(255, (b/max)*255*0.85))})\`;
        };

        const calculateCCT = (blueInt, yellowInt) => {
            const ratio = yellowInt / (blueInt + 0.001);
            if (ratio < 0.2) return 15000;
            if (ratio > 5) return 2000;
            return Math.round(7000 - Math.min(1, ratio / 2.5) * 4300);
        };

        const calculateCRI = (blueInt, yellowInt, redInt = 0) => {
            const ratio = yellowInt / (blueInt + 0.001);
            const balance = 1 - Math.abs(ratio - 1.2) / 2;
            let score = 72 + Math.max(0, balance * 12);
            if (redInt > 0) score += redInt * 14;
            return Math.min(98, Math.round(score));
        };

        function App() {
            const [blueIntensity, setBlueIntensity] = useState(${blueIntensity});
            const [yellowIntensity, setYellowIntensity] = useState(${yellowIntensity});
            const [redIntensity, setRedIntensity] = useState(${redIntensity});
            const [isRedEnabled, setIsRedEnabled] = useState(${isRedEnabled});

            const spectrumData = useMemo(() => {
                return WAVELENGTHS.map((wl) => {
                    const blue = blueIntensity * gaussian(wl, 450, 15);
                    const yellow = yellowIntensity * gaussian(wl, 560, 50);
                    const red = isRedEnabled ? redIntensity * gaussian(wl, 630, 20) : 0;
                    return { wavelength: wl, intensity: blue + yellow + red, blue, yellow, red };
                });
            }, [blueIntensity, yellowIntensity, redIntensity, isRedEnabled]);

            const outputColor = useMemo(() => spectrumToRGB(spectrumData.map(d => ({ x: d.wavelength, y: d.intensity }))), [spectrumData]);
            const cct = useMemo(() => calculateCCT(blueIntensity, yellowIntensity + (isRedEnabled ? redIntensity * 0.6 : 0)), [blueIntensity, yellowIntensity, redIntensity, isRedEnabled]);
            const cri = useMemo(() => calculateCRI(blueIntensity, yellowIntensity, isRedEnabled ? redIntensity : 0), [blueIntensity, yellowIntensity, redIntensity, isRedEnabled]);
            
            const chromaticity = useMemo(() => {
                const total = blueIntensity + yellowIntensity + (isRedEnabled ? redIntensity : 0) + 0.001;
                return {
                    x: (blueIntensity * 0.15 + yellowIntensity * 0.45 + (isRedEnabled ? redIntensity * 0.65 : 0)) / total,
                    y: (blueIntensity * 0.05 + yellowIntensity * 0.50 + (isRedEnabled ? redIntensity * 0.30 : 0)) / total
                };
            }, [blueIntensity, yellowIntensity, redIntensity, isRedEnabled]);

            useEffect(() => {
                const loader = document.getElementById('loading-screen');
                if (loader) {
                    loader.style.opacity = '0';
                    setTimeout(() => { loader.style.display = 'none'; }, 500);
                }
                if (window.lucide) window.lucide.createIcons();
            }, []);

            useEffect(() => {
                if (window.lucide) window.lucide.createIcons();
            }, [isRedEnabled]);

            if (!AreaChart) {
                return (
                    <div className="min-h-screen flex items-center justify-center bg-stone-50 p-6">
                        <div className="max-w-md w-full bg-white rounded-3xl p-8 shadow-xl border border-red-100 text-center">
                            <div className="w-16 h-16 bg-red-50 text-red-500 rounded-full flex items-center justify-center mx-auto mb-6">
                                <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
                            </div>
                            <h2 className="text-2xl font-bold text-stone-800 mb-4">Lỗi tải thư viện</h2>
                            <p className="text-stone-600 mb-8 leading-relaxed">
                                Không thể tải các thư viện cần thiết (Recharts, Motion). Vui lòng kiểm tra kết nối Internet và nhấn nút bên dưới để thử lại.
                            </p>
                            <button 
                                onClick={() => window.location.reload()}
                                className="w-full py-4 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-2xl transition-all shadow-lg shadow-blue-200"
                            >
                                Thử tải lại trang
                            </button>
                            <p className="mt-6 text-xs text-stone-400">
                                Nếu vẫn lỗi, hãy đảm bảo bạn không chặn các tên miền cdn.jsdelivr.net.
                            </p>
                        </div>
                    </div>
                );
            }

            return (
                <div className="min-h-screen bg-white text-[#1C1917] font-sans">
                    <header className="border-b border-stone-200 bg-white/80 backdrop-blur-md sticky top-0 z-50">
                        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
                            <div className="flex items-center gap-3">
                                <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center shadow-lg">
                                    <i data-lucide="zap" className="text-white"></i>
                                </div>
                                <div>
                                    <h1 className="text-xl font-bold tracking-tight">LED Phosphor Simulator (Offline)</h1>
                                    <p className="text-xs text-stone-500 font-medium uppercase tracking-wider">Bản lưu ngoại tuyến - ${reportDate}</p>
                                </div>
                            </div>
                        </div>
                    </header>

                    <main className="max-w-7xl mx-auto px-6 py-8 grid grid-cols-1 lg:grid-cols-12 gap-8">
                        <div className="lg:col-span-5 space-y-8">
                            <section className="bg-white rounded-3xl p-8 shadow-sm border border-stone-200">
                                <div className="relative h-80 flex items-center justify-center">
                                    <svg viewBox="0 0 400 300" className="w-full h-full">
                                        <defs>
                                            <marker id="arrowhead-blue" markerWidth="10" markerHeight="7" refX="0" refY="3.5" orient="auto"><polygon points="0 0, 10 3.5, 0 7" fill="#000099" /></marker>
                                            <marker id="arrowhead-yellow" markerWidth="10" markerHeight="7" refX="0" refY="3.5" orient="auto"><polygon points="0 0, 10 3.5, 0 7" fill="#EAB308" /></marker>
                                            <marker id="arrowhead-red" markerWidth="10" markerHeight="7" refX="0" refY="3.5" orient="auto"><polygon points="0 0, 10 3.5, 0 7" fill="#EF4444" /></marker>
                                            <marker id="arrowhead-white" markerWidth="10" markerHeight="7" refX="0" refY="3.5" orient="auto"><polygon points="0 0, 10 3.5, 0 7" fill="#000000" /></marker>
                                            <radialGradient id="glowGradient">
                                                <stop offset="0%" stopColor={outputColor} stopOpacity="0.8" />
                                                <stop offset="60%" stopColor={outputColor} stopOpacity="0.2" />
                                                <stop offset="100%" stopColor={outputColor} stopOpacity="0" />
                                            </radialGradient>
                                        </defs>
                                        <rect x="50" y="220" width="300" height="40" fill="#0F766E" rx="4" />
                                        <rect x="50" y="210" width="300" height="10" fill="#134E4A" />
                                        <rect x="160" y="208" width="80" height="4" fill="#000000" />
                                        <motion.rect x="160" y="190" width="80" height="18" fill="#000099" animate={{ fillOpacity: 0.5 + blueIntensity * 0.5 }} />
                                        <motion.rect x="155" y="180" width="90" height="10" fill="#FDE047" animate={{ fillOpacity: 0.4 + yellowIntensity * 0.6 }} />
                                        {isRedEnabled && <motion.rect x="155" y="176" width="90" height="4" fill="#EF4444" />}
                                        <motion.g animate={{ opacity: blueIntensity }}>
                                            <line x1="180" y1="195" x2="140" y2="140" stroke="#000099" strokeWidth="3" markerEnd="url(#arrowhead-blue)" strokeDasharray="4 2" />
                                            <line x1="200" y1="195" x2="200" y2="120" stroke="#000099" strokeWidth="3" markerEnd="url(#arrowhead-blue)" strokeDasharray="4 2" />
                                            <line x1="220" y1="195" x2="260" y2="140" stroke="#000099" strokeWidth="3" markerEnd="url(#arrowhead-blue)" strokeDasharray="4 2" />
                                        </motion.g>
                                        <motion.g animate={{ opacity: yellowIntensity }}>
                                            <line x1="170" y1="185" x2="135" y2="155" stroke="#EAB308" strokeWidth="3" markerEnd="url(#arrowhead-yellow)" strokeDasharray="4 2" />
                                            <line x1="200" y1="185" x2="200" y2="135" stroke="#EAB308" strokeWidth="3" markerEnd="url(#arrowhead-yellow)" strokeDasharray="4 2" />
                                            <line x1="230" y1="185" x2="265" y2="155" stroke="#EAB308" strokeWidth="3" markerEnd="url(#arrowhead-yellow)" strokeDasharray="4 2" />
                                        </motion.g>
                                        {isRedEnabled && (
                                            <motion.g animate={{ opacity: redIntensity }}>
                                                <line x1="175" y1="180" x2="125" y2="130" stroke="#EF4444" strokeWidth="3" markerEnd="url(#arrowhead-red)" strokeDasharray="4 2" />
                                                <line x1="200" y1="180" x2="200" y2="90" stroke="#EF4444" strokeWidth="3" markerEnd="url(#arrowhead-red)" strokeDasharray="4 2" />
                                                <line x1="225" y1="180" x2="275" y2="130" stroke="#EF4444" strokeWidth="3" markerEnd="url(#arrowhead-red)" strokeDasharray="4 2" />
                                            </motion.g>
                                        )}
                                        <path d="M100 210 Q 130 150 165 195" stroke="#C2410C" fill="none" strokeWidth="1.5" strokeOpacity="0.8" />
                                        <path d="M300 210 Q 270 150 235 195" stroke="#C2410C" fill="none" strokeWidth="1.5" strokeOpacity="0.8" />
                                        <path d="M70 210 A 130 130 0 0 1 330 210" fill="rgba(255, 255, 255, 0.1)" stroke="rgba(0, 0, 0, 0.2)" strokeWidth="1.5" />
                                        <path d="M110 160 A 100 100 0 0 1 180 100" fill="none" stroke="rgba(255, 255, 255, 0.3)" strokeWidth="4" strokeLinecap="round" />
                                        <motion.g animate={{ opacity: (blueIntensity + yellowIntensity + (isRedEnabled ? redIntensity : 0)) / 3 }}>
                                            <line x1="110" y1="110" x2="85" y2="80" stroke="#000000" strokeWidth="3" markerEnd="url(#arrowhead-white)" />
                                            <line x1="200" y1="80" x2="200" y2="45" stroke="#000000" strokeWidth="3" markerEnd="url(#arrowhead-white)" />
                                            <line x1="290" y1="110" x2="315" y2="80" stroke="#000000" strokeWidth="3" markerEnd="url(#arrowhead-white)" />
                                        </motion.g>
                                        <motion.circle cx="200" cy="150" r="130" fill="url(#glowGradient)" animate={{ scale: 0.7 + (blueIntensity + yellowIntensity + (isRedEnabled ? redIntensity : 0)) * 0.4, opacity: 0.4 + (blueIntensity + yellowIntensity + (isRedEnabled ? redIntensity : 0)) * 0.3 }} />
                                    </svg>
                                </div>
                                <div className="mt-8 flex items-center gap-4 p-4 bg-stone-50 rounded-2xl border border-stone-100">
                                    <motion.div className="w-16 h-16 rounded-full border-4 border-white" animate={{ backgroundColor: outputColor, boxShadow: \`0 0 40px \${outputColor}\` }} />
                                    <div>
                                        <p className="text-xs font-bold text-stone-400 uppercase tracking-widest">Mixed Output</p>
                                        <p className="text-lg font-mono font-bold text-stone-800">{outputColor.toUpperCase()}</p>
                                    </div>
                                </div>
                            </section>

                            <section className="bg-white rounded-3xl p-8 shadow-sm border border-stone-200 space-y-8">
                                <div className="space-y-6">
                                    <div className="flex items-center justify-between p-4 bg-stone-50 rounded-2xl">
                                        <span className="font-bold">Red Phosphor Option</span>
                                        <button onClick={() => setIsRedEnabled(!isRedEnabled)} className={\`h-6 w-11 rounded-full transition-colors \${isRedEnabled ? 'bg-red-500' : 'bg-stone-200'}\`}>
                                            <div className={\`h-4 w-4 bg-white rounded-full transform transition-transform \${isRedEnabled ? 'translate-x-6' : 'translate-x-1'}\`} />
                                        </button>
                                    </div>
                                    <div className="space-y-2">
                                        <div className="flex justify-between text-sm font-bold"><span>Blue LED Intensity</span><span>{(blueIntensity*100).toFixed(0)}%</span></div>
                                        <input type="range" min="0" max="1" step="0.01" value={blueIntensity} onChange={e => setBlueIntensity(parseFloat(e.target.value))} className="w-full" />
                                    </div>
                                    <div className="space-y-2">
                                        <div className="flex justify-between text-sm font-bold"><span>Phosphor Conversion</span><span>{(yellowIntensity*100).toFixed(0)}%</span></div>
                                        <input type="range" min="0" max="1" step="0.01" value={yellowIntensity} onChange={e => setYellowIntensity(parseFloat(e.target.value))} className="w-full" />
                                    </div>
                                    {isRedEnabled && (
                                        <div className="space-y-2">
                                            <div className="flex justify-between text-sm font-bold"><span>Red Phosphor Intensity</span><span>{(redIntensity*100).toFixed(0)}%</span></div>
                                            <input type="range" min="0" max="1" step="0.01" value={redIntensity} onChange={e => setRedIntensity(parseFloat(e.target.value))} className="w-full" />
                                        </div>
                                    )}
                                </div>
                                <div className="grid grid-cols-2 gap-4">
                                    <div className="p-4 bg-stone-50 rounded-2xl text-center"><p className="text-[10px] font-bold text-stone-400 uppercase">CCT</p><p className="text-2xl font-mono font-bold">{cct}K</p></div>
                                    <div className="p-4 bg-stone-50 rounded-2xl text-center"><p className="text-[10px] font-bold text-stone-400 uppercase">CRI</p><p className="text-2xl font-mono font-bold">{cri}</p></div>
                                </div>
                            </section>
                        </div>

                        <div className="lg:col-span-7 space-y-8">
                            <section className="bg-white rounded-3xl p-8 shadow-sm border border-stone-200 h-full flex flex-col">
                                <div className="flex-1 min-h-[400px]">
                                    <ResponsiveContainer width="100%" height="100%">
                                        <AreaChart data={spectrumData}>
                                            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#F5F5F4" />
                                            <XAxis dataKey="wavelength" tick={{fontSize: 10}} />
                                            <YAxis hide domain={[0, 1.2]} />
                                            <Tooltip />
                                            <Area type="monotone" dataKey="intensity" stroke={outputColor} fill={outputColor} fillOpacity={0.1} isAnimationActive={false} />
                                        </AreaChart>
                                    </ResponsiveContainer>
                                </div>
                                <div className="mt-8 p-6 bg-stone-50 rounded-3xl border border-stone-100">
                                    <div className="flex items-center justify-between mb-4">
                                        <h3 className="text-xs font-bold text-stone-400 uppercase tracking-widest">CIE 1931 Chromaticity</h3>
                                        <span className="text-[10px] font-mono text-stone-500">x: {chromaticity.x.toFixed(3)}, y: {chromaticity.y.toFixed(3)}</span>
                                    </div>
                                    <div className="relative aspect-square max-w-[200px] mx-auto bg-white rounded-xl border border-stone-200 overflow-hidden">
                                        <div className="absolute inset-0 bg-gradient-to-tr from-blue-500 via-green-400 to-red-500 opacity-20" />
                                        <svg viewBox="0 0 100 100" className="absolute inset-0 w-full h-full">
                                            <path d="M20 80 Q 40 40 80 20" stroke="#A8A29E" fill="none" strokeWidth="1" strokeDasharray="2 2" />
                                            <circle cx={chromaticity.x * 100} cy={100 - chromaticity.y * 100} r="4" fill={outputColor} stroke="white" strokeWidth="2" />
                                        </svg>
                                    </div>
                                </div>
                            </section>
                        </div>
                    </main>
                </div>
            );
        }

        const root = ReactDOM.createRoot(document.getElementById('root'));
        root.render(<App />);
    </script>
</body>
</html>`;

    const blob = new Blob([htmlContent], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `LED_Simulator_Offline_${new Date().getTime()}.html`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen bg-white text-[#1C1917] font-sans selection:bg-blue-100">
      {/* Header */}
      <header className="border-b border-stone-200 bg-white/80 backdrop-blur-md sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center shadow-lg shadow-blue-200">
              <Zap className="text-white w-6 h-6" />
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-tight">LED Phosphor Simulator</h1>
              <p className="text-xs text-stone-500 font-medium uppercase tracking-wider">Optics & Photonics Lab</p>
            </div>
          </div>
          <div className="hidden md:flex items-center gap-4 text-sm font-medium text-stone-600">
            <button 
              onClick={handleExportHTML}
              className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 rounded-xl transition-colors text-white shadow-md shadow-blue-100"
            >
              <Download size={18} />
              <span>Tải về Thí nghiệm (Offline)</span>
            </button>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-blue-500 animate-pulse" />
              <span>Live Simulation</span>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 py-8 grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Column: Visualization & Controls */}
        <div className="lg:col-span-5 space-y-8">
          
          {/* LED Structure Visualization */}
          <section className="bg-white rounded-3xl p-8 shadow-sm border border-stone-200 overflow-hidden relative">
            <div className="flex items-center justify-between mb-8">
              <h2 className="text-sm font-bold uppercase tracking-widest text-stone-400 flex items-center gap-2">
                <Settings2 size={16} /> Optical Path Simulation
              </h2>
            </div>

            <div className="relative h-80 flex items-center justify-center">
              {/* LED Cross-section SVG */}
              <svg viewBox="0 0 400 300" className="w-full h-full">
                <defs>
                  <marker id="arrowhead-blue" markerWidth="10" markerHeight="7" refX="0" refY="3.5" orient="auto">
                    <polygon points="0 0, 10 3.5, 0 7" fill="#000099" />
                  </marker>
                  <marker id="arrowhead-yellow" markerWidth="10" markerHeight="7" refX="0" refY="3.5" orient="auto">
                    <polygon points="0 0, 10 3.5, 0 7" fill="#EAB308" />
                  </marker>
                  <marker id="arrowhead-red" markerWidth="10" markerHeight="7" refX="0" refY="3.5" orient="auto">
                    <polygon points="0 0, 10 3.5, 0 7" fill="#EF4444" />
                  </marker>
                  <marker id="arrowhead-white" markerWidth="10" markerHeight="7" refX="0" refY="3.5" orient="auto">
                    <polygon points="0 0, 10 3.5, 0 7" fill="#000000" />
                  </marker>
                  <radialGradient id="glowGradient">
                    <stop offset="0%" stopColor={outputColor} stopOpacity="0.8" />
                    <stop offset="60%" stopColor={outputColor} stopOpacity="0.2" />
                    <stop offset="100%" stopColor={outputColor} stopOpacity="0" />
                  </radialGradient>
                </defs>

                {/* Ceramic Substrate (Dark Turquoise) */}
                <rect x="50" y="220" width="300" height="40" fill="#0F766E" rx="4" />
                <rect x="50" y="210" width="300" height="10" fill="#134E4A" />
                
                {/* Thermal Pad & Contacts */}
                <rect x="150" y="260" width="100" height="5" fill="#115E59" />
                <rect x="70" y="260" width="40" height="5" fill="#F59E0B" />
                <rect x="290" y="260" width="40" height="5" fill="#F59E0B" />

                {/* Adhesive Layer (Doubled) */}
                <rect x="160" y="208" width="80" height="4" fill="#000000" />

                {/* LED Chip */}
                <motion.rect 
                  x="160" y="190" width="80" height="18" 
                  fill="#000099" 
                  animate={{ fillOpacity: 0.5 + blueIntensity * 0.5 }}
                />
                
                {/* Phosphor Layer */}
                <motion.rect 
                  x="155" y="180" width="90" height="10" 
                  fill="#FDE047" 
                  animate={{ fillOpacity: 0.4 + yellowIntensity * 0.6 }}
                />

                {/* Red Phosphor Layer (Optional) */}
                <AnimatePresence>
                  {isRedEnabled && (
                    <motion.rect 
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 4 }}
                      exit={{ opacity: 0, height: 0 }}
                      x="155" y="176" width="90" 
                      fill="#EF4444" 
                      className="rounded-t-sm"
                    />
                  )}
                </AnimatePresence>

                {/* Inside Rays: Blue */}
                <motion.g animate={{ opacity: blueIntensity }}>
                  <line x1="180" y1="195" x2="140" y2="140" stroke="#000099" strokeWidth="3" markerEnd="url(#arrowhead-blue)" strokeDasharray="4 2" />
                  <line x1="200" y1="195" x2="200" y2="120" stroke="#000099" strokeWidth="3" markerEnd="url(#arrowhead-blue)" strokeDasharray="4 2" />
                  <line x1="220" y1="195" x2="260" y2="140" stroke="#000099" strokeWidth="3" markerEnd="url(#arrowhead-blue)" strokeDasharray="4 2" />
                </motion.g>

                {/* Inside Rays: Yellow (Inside the shell) */}
                <motion.g animate={{ opacity: yellowIntensity }}>
                  <line x1="170" y1="185" x2="135" y2="155" stroke="#EAB308" strokeWidth="3" markerEnd="url(#arrowhead-yellow)" strokeDasharray="4 2" />
                  <line x1="200" y1="185" x2="200" y2="125" stroke="#EAB308" strokeWidth="3" markerEnd="url(#arrowhead-yellow)" strokeDasharray="4 2" />
                  <line x1="230" y1="185" x2="265" y2="155" stroke="#EAB308" strokeWidth="3" markerEnd="url(#arrowhead-yellow)" strokeDasharray="4 2" />
                </motion.g>

                {/* Inside Rays: Red */}
                <motion.g animate={{ opacity: isRedEnabled ? redIntensity : 0 }}>
                  <line x1="175" y1="180" x2="125" y2="130" stroke="#EF4444" strokeWidth="3" markerEnd="url(#arrowhead-red)" strokeDasharray="4 2" />
                  <line x1="200" y1="180" x2="200" y2="101" stroke="#EF4444" strokeWidth="3" markerEnd="url(#arrowhead-red)" strokeDasharray="4 2" />
                  <line x1="225" y1="180" x2="275" y2="130" stroke="#EF4444" strokeWidth="3" markerEnd="url(#arrowhead-red)" strokeDasharray="4 2" />
                </motion.g>

                {/* Bond Wires */}
                <path d="M100 210 Q 130 150 165 195" stroke="#C2410C" fill="none" strokeWidth="1.5" strokeOpacity="0.8" />
                <path d="M300 210 Q 270 150 235 195" stroke="#C2410C" fill="none" strokeWidth="1.5" strokeOpacity="0.8" />

                {/* Primary Lens (Dome) with Glass Effect and Visible Border */}
                <path d="M70 210 A 130 130 0 0 1 330 210" fill="rgba(255, 255, 255, 0.1)" stroke="rgba(0, 0, 0, 0.2)" strokeWidth="1.5" />
                <path d="M70 210 A 130 130 0 0 1 330 210" fill="none" stroke="rgba(255, 255, 255, 0.5)" strokeWidth="1" transform="translate(0, -1)" />
                <path d="M110 160 A 100 100 0 0 1 180 100" fill="none" stroke="rgba(255, 255, 255, 0.3)" strokeWidth="4" strokeLinecap="round" />
                <path d="M240 110 A 100 100 0 0 1 270 130" fill="none" stroke="rgba(255, 255, 255, 0.2)" strokeWidth="2" strokeLinecap="round" />

                {/* Outside Rays: Mixed White (Shortened) */}
                <motion.g animate={{ opacity: (blueIntensity + yellowIntensity + (isRedEnabled ? redIntensity : 0)) / 3 }}>
                  <line x1="110" y1="110" x2="85" y2="80" stroke="#000000" strokeWidth="3" markerEnd="url(#arrowhead-white)" />
                  <line x1="200" y1="75" x2="200" y2="40" stroke="#000000" strokeWidth="3" markerEnd="url(#arrowhead-white)" />
                  <line x1="290" y1="110" x2="315" y2="80" stroke="#000000" strokeWidth="3" markerEnd="url(#arrowhead-white)" />
                  
                  <text x="215" y="50" fill="#000000" fontSize="11" fontWeight="900" className="uppercase tracking-widest">White Light</text>
                </motion.g>
                
                {/* Light Emission Glow */}
                <motion.circle 
                  cx="200" cy="150" r="130" 
                  fill="url(#glowGradient)"
                  animate={{ 
                    scale: 0.7 + (blueIntensity + yellowIntensity + (isRedEnabled ? redIntensity : 0)) * 0.4,
                    opacity: 0.4 + (blueIntensity + yellowIntensity + (isRedEnabled ? redIntensity : 0)) * 0.3
                  }}
                />
              </svg>
            </div>

            {/* Output Light Result */}
            <div className="mt-8 flex items-center gap-4 p-4 bg-stone-50 rounded-2xl border border-stone-100">
              <motion.div 
                className="w-16 h-16 rounded-full shadow-inner border-4 border-white"
                animate={{ backgroundColor: outputColor, boxShadow: `0 0 40px ${outputColor}` }}
                transition={{ duration: 0.3 }}
              />
              <div>
                <p className="text-xs font-bold text-stone-400 uppercase tracking-widest">Mixed Output</p>
                <p className="text-lg font-mono font-bold text-stone-800">{outputColor.toUpperCase()}</p>
              </div>
            </div>
          </section>

          {/* Scene Preview */}
          <section className="bg-white rounded-3xl p-8 shadow-sm border border-stone-200 overflow-hidden">
            <h2 className="text-sm font-bold uppercase tracking-widest text-stone-400 mb-6 flex items-center gap-2">
              <Sun size={16} /> Application Scene
            </h2>
            <div className="relative h-48 rounded-2xl overflow-hidden bg-stone-100 flex items-center justify-center">
              {/* Simple Room Scene */}
              <div className="absolute inset-0 grid grid-cols-2 gap-2 p-4">
                <div className="bg-white rounded-lg shadow-sm" />
                <div className="bg-stone-200 rounded-lg shadow-sm" />
              </div>
              {/* Light Overlay */}
              <motion.div 
                className="absolute inset-0 mix-blend-multiply"
                animate={{ backgroundColor: outputColor, opacity: 0.6 }}
                transition={{ duration: 0.3 }}
              />
              <div className="z-10 text-center">
                <p className="text-[10px] font-bold text-stone-500 uppercase tracking-widest mb-2">Illumination Effect</p>
                <div className="flex gap-2 justify-center">
                  <div className="w-8 h-8 rounded-full bg-red-500 shadow-sm" />
                  <div className="w-8 h-8 rounded-full bg-green-500 shadow-sm" />
                  <div className="w-8 h-8 rounded-full bg-blue-500 shadow-sm" />
                </div>
              </div>
            </div>
          </section>

          {/* Controls */}
          <section className="bg-white rounded-3xl p-8 shadow-sm border border-stone-200 space-y-8">
            <h2 className="text-sm font-bold uppercase tracking-widest text-stone-400 flex items-center gap-2">
              <Activity size={16} /> Parameters
            </h2>

            <div className="space-y-6">
              <div className="flex items-center justify-between p-4 bg-stone-50 rounded-2xl border border-stone-100">
                <div className="flex items-center gap-3">
                  <div className={cn("w-10 h-10 rounded-xl flex items-center justify-center transition-colors", isRedEnabled ? "bg-red-100 text-red-600" : "bg-stone-100 text-stone-400")}>
                    <Sun size={20} />
                  </div>
                  <div>
                    <p className="text-sm font-bold text-stone-800">Red Phosphor Option</p>
                    <p className="text-[10px] text-stone-500 uppercase font-bold tracking-wider">Enhance CRI & Warmth</p>
                  </div>
                </div>
                <button 
                  onClick={() => setIsRedEnabled(!isRedEnabled)}
                  className={cn(
                    "relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none",
                    isRedEnabled ? "bg-red-500" : "bg-stone-200"
                  )}
                >
                  <span className={cn("inline-block h-4 w-4 transform rounded-full bg-white transition-transform", isRedEnabled ? "translate-x-6" : "translate-x-1")} />
                </button>
              </div>

              <div className="space-y-3">
                <div className="flex justify-between items-end">
                  <label className="text-sm font-bold text-blue-600 flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full bg-blue-500" /> Blue LED Intensity
                  </label>
                  <span className="text-xs font-mono bg-blue-50 text-blue-600 px-2 py-1 rounded-md">{(blueIntensity * 100).toFixed(0)}%</span>
                </div>
                <input 
                  type="range" min="0" max="1" step="0.01" 
                  value={blueIntensity} 
                  onChange={(e) => setBlueIntensity(parseFloat(e.target.value))}
                  className="w-full h-2 bg-blue-100 rounded-lg appearance-none cursor-pointer accent-blue-600"
                />
              </div>

              <div className="space-y-3">
                <div className="flex justify-between items-end">
                  <label className="text-sm font-bold text-yellow-600 flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full bg-yellow-400" /> Phosphor Conversion
                  </label>
                  <span className="text-xs font-mono bg-yellow-50 text-yellow-700 px-2 py-1 rounded-md">{(yellowIntensity * 100).toFixed(0)}%</span>
                </div>
                <input 
                  type="range" min="0" max="1" step="0.01" 
                  value={yellowIntensity} 
                  onChange={(e) => setYellowIntensity(parseFloat(e.target.value))}
                  className="w-full h-2 bg-yellow-100 rounded-lg appearance-none cursor-pointer accent-yellow-500"
                />
              </div>

              <AnimatePresence>
                {isRedEnabled && (
                  <motion.div 
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    className="space-y-3 overflow-hidden"
                  >
                    <div className="flex justify-between items-end">
                      <label className="text-sm font-bold text-red-600 flex items-center gap-2">
                        <div className="w-2 h-2 rounded-full bg-red-500" /> Red Phosphor Intensity
                      </label>
                      <span className="text-xs font-mono bg-red-50 text-red-600 px-2 py-1 rounded-md">{(redIntensity * 100).toFixed(0)}%</span>
                    </div>
                    <input 
                      type="range" min="0" max="1" step="0.01" 
                      value={redIntensity} 
                      onChange={(e) => setRedIntensity(parseFloat(e.target.value))}
                      className="w-full h-2 bg-red-100 rounded-lg appearance-none cursor-pointer accent-red-500"
                    />
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            <div className="pt-4 border-t border-stone-100 grid grid-cols-2 gap-4">
              <div className="p-4 bg-stone-50 rounded-2xl">
                <p className="text-[10px] font-bold text-stone-400 uppercase mb-1">CCT (Temp)</p>
                <p className="text-2xl font-mono font-bold text-stone-800">{cct}K</p>
              </div>
              <div className="p-4 bg-stone-50 rounded-2xl">
                <p className="text-[10px] font-bold text-stone-400 uppercase mb-1">CRI (Ra)</p>
                <p className="text-2xl font-mono font-bold text-stone-800">{cri}</p>
              </div>
            </div>
          </section>
        </div>

        {/* Right Column: Spectrum Analysis */}
        <div className="lg:col-span-7 space-y-8">
          
          {/* Spectral Power Distribution */}
          <section className="bg-white rounded-3xl p-8 shadow-sm border border-stone-200 h-full flex flex-col">
            <div className="flex items-center justify-between mb-8">
              <h2 className="text-sm font-bold uppercase tracking-widest text-stone-400 flex items-center gap-2">
                <Activity size={16} /> Spectral Power Distribution
              </h2>
              <div className="flex gap-4">
                <div className="flex items-center gap-2 text-[10px] font-bold text-blue-500 uppercase">
                  <div className="w-3 h-1 bg-blue-500 rounded-full" /> Blue Peak
                </div>
                <div className="flex items-center gap-2 text-[10px] font-bold text-yellow-500 uppercase">
                  <div className="w-3 h-1 bg-yellow-500 rounded-full" /> Phosphor
                </div>
                {isRedEnabled && (
                  <div className="flex items-center gap-2 text-[10px] font-bold text-red-500 uppercase">
                    <div className="w-3 h-1 bg-red-500 rounded-full" /> Red Phosphor
                  </div>
                )}
              </div>
            </div>

            <div className="flex-1 min-h-[400px]">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={spectrumData} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                  <defs>
                    <linearGradient id="colorTotal" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor={outputColor} stopOpacity={0.2}/>
                      <stop offset="95%" stopColor={outputColor} stopOpacity={0}/>
                    </linearGradient>
                    <linearGradient id="colorBlue" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#3B82F6" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="#3B82F6" stopOpacity={0}/>
                    </linearGradient>
                    <linearGradient id="colorYellow" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#EAB308" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="#EAB308" stopOpacity={0}/>
                    </linearGradient>
                    <linearGradient id="colorRed" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#EF4444" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="#EF4444" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#F5F5F4" />
                  <XAxis 
                    dataKey="wavelength" 
                    tick={{ fontSize: 10, fill: '#A8A29E' }} 
                    axisLine={false}
                    tickLine={false}
                    label={{ value: 'Wavelength (nm)', position: 'insideBottom', offset: -10, fontSize: 10, fill: '#A8A29E' }}
                  />
                  <YAxis 
                    hide 
                    domain={[0, 1.2]}
                  />
                  <Tooltip 
                    contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)', fontSize: '12px' }}
                    formatter={(value: number) => [value.toFixed(3), 'Relative Intensity']}
                  />
                  <Area 
                    type="monotone" 
                    dataKey="blue" 
                    stroke="#3B82F6" 
                    strokeWidth={2}
                    fillOpacity={1} 
                    fill="url(#colorBlue)" 
                    isAnimationActive={false}
                  />
                  <Area 
                    type="monotone" 
                    dataKey="yellow" 
                    stroke="#EAB308" 
                    strokeWidth={2}
                    fillOpacity={1} 
                    fill="url(#colorYellow)" 
                    isAnimationActive={false}
                  />
                  <Area 
                    type="monotone" 
                    dataKey="red" 
                    stroke="#EF4444" 
                    strokeWidth={2}
                    fillOpacity={1} 
                    fill="url(#colorRed)" 
                    isAnimationActive={false}
                  />
                  <Area 
                    type="monotone" 
                    dataKey="intensity" 
                    stroke={outputColor} 
                    strokeWidth={3}
                    fillOpacity={1} 
                    fill="url(#colorTotal)" 
                    isAnimationActive={false}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>

            {/* Chromaticity Diagram */}
            <div className="mt-8 p-6 bg-stone-50 rounded-3xl border border-stone-100">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-xs font-bold text-stone-400 uppercase tracking-widest">CIE 1931 Chromaticity</h3>
                <span className="text-[10px] font-mono text-stone-500">x: {chromaticity.x.toFixed(3)}, y: {chromaticity.y.toFixed(3)}</span>
              </div>
              <div className="relative aspect-square max-w-[200px] mx-auto bg-white rounded-xl border border-stone-200 overflow-hidden">
                {/* Simplified Chromaticity Background */}
                <div className="absolute inset-0 bg-gradient-to-tr from-blue-500 via-green-400 to-red-500 opacity-20" />
                {/* Planckian Locus (Simplified) */}
                <svg viewBox="0 0 100 100" className="absolute inset-0 w-full h-full">
                  <path d="M20 80 Q 40 40 80 20" stroke="#A8A29E" fill="none" strokeWidth="1" strokeDasharray="2 2" />
                  {/* Current Point */}
                  <motion.circle 
                    cx={chromaticity.x * 100} 
                    cy={100 - chromaticity.y * 100} 
                    r="4" 
                    fill={outputColor} 
                    stroke="white" 
                    strokeWidth="2"
                    animate={{ cx: chromaticity.x * 100, cy: 100 - chromaticity.y * 100 }}
                    transition={{ type: "spring", stiffness: 100 }}
                  />
                </svg>
              </div>
            </div>

            <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="p-6 rounded-2xl bg-stone-50 border border-stone-100">
                <div className="flex items-center gap-2 mb-2">
                  <Sun className="text-yellow-500 w-4 h-4" />
                  <h3 className="text-xs font-bold text-stone-400 uppercase">Color Quality</h3>
                </div>
                <p className="text-sm text-stone-600 leading-relaxed">
                  {cri > 80 ? "Excellent color rendering. Suitable for indoor lighting and photography." : "Standard color rendering. Good for general illumination."}
                </p>
              </div>
              <div className="p-6 rounded-2xl bg-stone-50 border border-stone-100">
                <div className="flex items-center gap-2 mb-2">
                  <Activity className="text-blue-500 w-4 h-4" />
                  <h3 className="text-xs font-bold text-stone-400 uppercase">CCT Analysis</h3>
                </div>
                <p className="text-sm text-stone-600 leading-relaxed">
                  {cct > 5000 ? "Cool White light. Promotes alertness and focus." : "Warm White light. Creates a cozy and relaxing atmosphere."}
                </p>
              </div>
              <div className="p-6 rounded-2xl bg-stone-50 border border-stone-100">
                <div className="flex items-center gap-2 mb-2">
                  <Info className="text-stone-400 w-4 h-4" />
                  <h3 className="text-xs font-bold text-stone-400 uppercase">Physics Note</h3>
                </div>
                <p className="text-sm text-stone-600 leading-relaxed">
                  {isRedEnabled 
                    ? "Advanced LED using dual-phosphor (YAG + Nitride) to achieve high CRI and warm spectral coverage."
                    : "Standard blue photons (~450nm) excite the YAG:Ce phosphor, which re-emits lower energy yellow photons."}
                </p>
              </div>
            </div>
          </section>
        </div>
      </main>

      {/* Footer */}
      <footer className="max-w-7xl mx-auto px-6 py-12 border-t border-stone-200 mt-12">
        <div className="flex flex-col md:flex-row justify-between items-center gap-6">
          <p className="text-xs text-stone-400 font-medium uppercase tracking-widest">
            © 2026 LED Simulation Module • Triet.nm
          </p>
          <div className="flex gap-8">
            <a href="#" className="text-xs font-bold text-stone-400 hover:text-stone-600 uppercase tracking-widest transition-colors">Documentation</a>
            <a href="#" className="text-xs font-bold text-stone-400 hover:text-stone-600 uppercase tracking-widest transition-colors">Source Code</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
